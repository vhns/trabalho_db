from utils.create_db import create_db
from models import *
from services.database import session

if __name__ == "__main__":
    create_db()