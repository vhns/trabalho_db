from models.base import Base
from models.person import Person
from models.phone import Phone
from models.email import Email
from models.client import Client
from models.employee import Employee